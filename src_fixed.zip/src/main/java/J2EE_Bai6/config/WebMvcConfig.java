package J2EE_Bai6.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import java.nio.file.Paths;

@Configuration
public class WebMvcConfig implements WebMvcConfigurer {

    @Value("${app.upload.dir:#{null}}")
    private String configuredUploadDir;

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        String uploadPath;
        if (configuredUploadDir != null && !configuredUploadDir.isBlank()) {
            uploadPath = Paths.get(configuredUploadDir).toAbsolutePath().toString();
        } else {
            uploadPath = Paths.get(System.getProperty("user.dir"),
                    "src", "main", "resources", "static", "images")
                    .toAbsolutePath().toString();
        }

        // Map /images/** → the actual upload folder on disk
        registry.addResourceHandler("/images/**")
                .addResourceLocations("file:" + uploadPath + "/");
    }
}
